#include "Ray.h"

Ray::Ray( double originX, double originY, double originZ ) :
    _x( originX ),
    _y( originY ),
    _z( originZ )
{
}


Ray::~Ray()
{
}
